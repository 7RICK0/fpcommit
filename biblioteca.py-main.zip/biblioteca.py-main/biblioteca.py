import csv
import os

ARQUIVO_CSV = 'biblioteca.csv'

def limpar_tela():
    print('\n' * 50)

def carregar_biblioteca():
    biblioteca = []
    if os.path.exists(ARQUIVO_CSV):
        with open(ARQUIVO_CSV, 'r', newline='') as arquivo:
            leitor_csv = csv.DictReader(arquivo)
            for linha in leitor_csv:
                biblioteca.append(linha)
    return biblioteca

def salvar_biblioteca(biblioteca):
    with open(ARQUIVO_CSV, 'w', newline='') as arquivo:
        campos = ['Nome', 'Autor', 'Categoria', 'Custo']
        escritor_csv = csv.DictWriter(arquivo, fieldnames=campos)
        escritor_csv.writeheader()
        escritor_csv.writerows(biblioteca)

def cadastrar_livro():
    nome = input('Digite o nome do livro: ')
    autor = input('Digite o autor do livro: ')
    categoria = input('Qual a categoria do livro: ')

    while True:
        try:
            custo = float(input('Quanto custou o livro: '))
            break
        except ValueError:
            print("Por favor, insira um valor numérico válido.")

    return {'Nome': nome, 'Autor': autor, 'Categoria': categoria, 'Custo': custo}

def excluir_livro(biblioteca, nome_livro):
    for livro in biblioteca:
        if livro['Nome'].lower() == nome_livro.lower():
            biblioteca.remove(livro)
            print(f'O livro {nome_livro} foi removido.')
            salvar_biblioteca(biblioteca)
            return
    print(f'O livro {nome_livro} não foi encontrado.')

def atualizar_livro(biblioteca, nome_livro):
    for i, livro in enumerate(biblioteca):
        if livro['Nome'].lower() == nome_livro.lower():
            novo_livro = cadastrar_livro()
            biblioteca[i] = novo_livro
            print(f'O livro {nome_livro} foi atualizado.')
            salvar_biblioteca(biblioteca)
            return
    print(f'O livro {nome_livro} não foi encontrado.')

def listar_livros(biblioteca):
    if not biblioteca:
        print("A biblioteca está vazia.")
    else:
        for livro in biblioteca:
            print(f"{livro['Nome']} - {livro['Autor']} - {livro['Categoria']} - R${livro['Custo']}")

def listar_livros_por_categoria(biblioteca, categoria):
    for livro in biblioteca:
        if livro['Categoria'].lower() == categoria.lower():
            print(f"{livro['Nome']} - {livro['Autor']} - {livro['Categoria']} - R${livro['Custo']}")

def calcular_gastos_totais(biblioteca):
    total_gastos = sum(float(livro['Custo']) for livro in biblioteca)
    print(f"Total de gastos em sua coleção de livros: R${total_gastos:.2f}")

def confirma_voltar():
    resposta = input("Deseja voltar à tela inicial da biblioteca? (sim/não): ")
    return resposta.lower() == 'sim'

def apagar_todos_itens(biblioteca):
    confirmacao = input("Tem certeza que deseja apagar todos os itens da biblioteca? (sim/não): ")
    if confirmacao.lower() == 'sim':
        biblioteca.clear()
        salvar_biblioteca(biblioteca)
        print("Todos os itens da biblioteca foram apagados.")
    else:
        print("Operação cancelada.")

def main():
    biblioteca = carregar_biblioteca()

    while True:
        limpar_tela()
        print("=== Gerenciamento de Biblioteca Pessoal ===")
        print("1. Cadastrar Livro")
        print("2. Listar Todos os Livros")
        print("3. Listar Livros por Categoria")
        print("4. Excluir Livro")
        print("5. Atualizar Livro")
        print("6. Apagar Todos os Itens da Biblioteca")
        print("7. Calcular Gastos Totais")
        print("8. Sair")

        escolha = input("Escolha uma opção: ")

        if escolha == '1':
            livro = cadastrar_livro()
            biblioteca.append(livro)
            salvar_biblioteca(biblioteca)
        elif escolha == '2':
            listar_livros(biblioteca)
        elif escolha == '3':
            categoria = input('Digite a categoria para filtrar os livros: ')
            listar_livros_por_categoria(biblioteca, categoria)
        elif escolha == '4':
            listar_livros(biblioteca)
            nome_livro = input('Digite o nome do livro que deseja excluir: ')
            excluir_livro(biblioteca, nome_livro)
        elif escolha == '5':
            listar_livros(biblioteca)
            nome_livro = input('Digite o nome do livro que deseja atualizar: ')
            atualizar_livro(biblioteca, nome_livro)
        elif escolha == '6':
            apagar_todos_itens(biblioteca)
        elif escolha == '7':
            calcular_gastos_totais(biblioteca)
        elif escolha == '8':
            print("A biblioteca foi fechada, deseja reabri-la?")
            if input("(sim/não): ").lower() == 'não':
                print("A biblioteca foi fechada.")
                break

        if not confirma_voltar():
            print("A biblioteca foi fechada.")
            break

if __name__ == "__main__":
    main()
